# 幕友（maku-watch）前端交付包

- 站点版本：Sites v19
- 源码提交：`1a23ddb28fc1bf7abf1ffc97d2413fe0745b2d1b`
- 打包日期：2026-09-04
- Node.js：`>= 22.13.0`

## 目录说明

- `source/`：完整前端源码，不含 `.git`、`node_modules`、本地环境变量和缓存文件。
- `build/`：已验证通过的生产构建产物，包含 Cloudflare Worker 入口和静态资源。

## 从源码构建

```bash
cd source
npm ci
npm run build
```

构建产物默认输出到 `source/dist/`。

## 生产构建入口

- Worker 入口：`build/server/index.js`
- 静态资源：`build/client/`

